--Library Management System

--Create 'LibraryDB' database

CREATE DATABASE LibraryDB

USE LibraryDB

--Create 'Authors' table

CREATE TABLE Authors(AuthorID INT PRIMARY KEY IDENTITY(1,1),
FirstName NVARCHAR(50) NOT NULL,
LastName NVARCHAR(50) NOT NULL,
BirthDate DATE)

--Insert sample data into 'Authors' table

INSERT INTO Authors
VALUES ('George', 'Orwell', '1903-06-25'),
('J.K.', 'Rowling', '1965-07-31'),
('Stephen', 'King', '1947-09-21'),
('Agatha', 'Christie', '1890-09-15')

--Create 'Books' table

CREATE TABLE Books(BookID INT PRIMARY KEY IDENTITY(1,1),
Title NVARCHAR(100) NOT NULL,
AuthorID INT FOREIGN KEY REFERENCES Authors(AuthorID),
PublicationYear INT , Genre NVARCHAR(50))

--Insert sample data into 'Books' table

INSERT INTO Books
VALUES ('1984', 1, 1949, 'Dystopian'),
('Animal Farm', 1, 1945, 'Political Satire'),

('Harry Potter and the Prisoner of Azkaban', 2, 1997, 'Fantasy'),
('Harry Potter and the Chamber of Secrets', 2, 1998, 'Fantasy'),

('The Shining', 3, 1977, 'Horror'),
('It', 3, 1986, 'Horror'),

('Murder on the Orient Express', 4, 1934, 'Mystery'),
('And Then There Were None', 4, 1939, 'Mystery')

--Create 'Members' Table

CREATE TABLE Members ( MemberID INT PRIMARY KEY IDENTITY(1,1),
FullName NVARCHAR(100) NOT NULL,
MembershipDate DATE,
Email NVARCHAR(100) )

--Insert sample data into 'Members' table

INSERT INTO Members
VALUES ('Sophia Carter', '2023-04-10', 'sophia.carter@example.com'),
('Liam Anderson', '2023-05-22', 'liam.anderson@example.com'),
('Olivia Martinez', '2023-06-14', 'olivia.martinez@example.com'),
('Ethan Johnson', '2023-07-03', 'ethan.johnson@example.com'),
('Ava Thompson', '2023-08-19', 'ava.thompson@example.com')

--Retrieve Authors

SELECT * FROM Authors

--Retrieve Books

SELECT * FROM Books

--Retrieve Members

SELECT * FROM Members

--Create 'Transaction' table to keep a track of the same

CREATE TABLE Transactions (TransactionID INT PRIMARY KEY IDENTITY(1,1),
    BookID INT FOREIGN KEY REFERENCES Books(BookID),
    MemberID INT FOREIGN KEY REFERENCES Members(MemberID),
    BorrowDate DATE NOT NULL,
    ReturnDate DATE NULL,
    Returned BIT DEFAULT 0)

--Insert values into 'Transaction' table

INSERT INTO Transactions
VALUES (1, 1, '2023-09-10', '2023-09-20', 1),
(3, 2, '2023-09-15', NULL, 0),
(5, 3, '2023-09-18', '2023-09-25', 1),
(7, 4, '2023-09-22', NULL, 0);

--Check transaction history

SELECT * FROM Transactions

--Search book names

SELECT * FROM Books WHERE Title like '%Harry Potter%'